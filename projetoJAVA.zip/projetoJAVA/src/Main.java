import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        // Criar uma pessoa
        System.out.println("Informe o nome da pessoa:");
        String nomePessoa = scanner.nextLine();

        System.out.println("Informe a idade da pessoa:");
        int idadePessoa = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha pendente

        System.out.println("Informe a nacionalidade da pessoa:");
        String nacionalidadePessoa = scanner.nextLine();

        DadosPessoa pessoa = new DadosPessoa(nomePessoa, idadePessoa, nacionalidadePessoa);

        // Verificar se a pessoa pode dirigir
        if (pessoa.podeDirigir()) {
            System.out.println("A pessoa pode dirigir.");
        } else {
            System.out.println("A pessoa não pode dirigir.");
        }

        // Verificar se a pessoa está apta a um concurso
        if (pessoa.aptoConcurso()) {
            System.out.println("A pessoa está apta a participar de um concurso.");
        } else {
            System.out.println("A pessoa não está apta a participar de um concurso.");
        }

        // Inserir 3 produtos e verificar se são de alto valor
        for (int i = 1; i <= 3; i++) {
            System.out.println("Informe o nome do produto " + i + ":");
            String nomeProduto = scanner.nextLine();

            System.out.println("Informe o valor do produto " + i + ":");
            double valorProduto = scanner.nextDouble();
            scanner.nextLine(); // Consumir a quebra de linha pendente

            ProdutoValor produto = new ProdutoValor(nomeProduto, valorProduto);

            // Verificar se o produto é de alto valor
            if (produto.altoValor()) {
                System.out.println("O produto " + produto.nome + " é de alto valor.");
            } else {
                System.out.println("O produto " + produto.nome + " não é de alto valor.");
            }
        }

        scanner.close();
    }
}