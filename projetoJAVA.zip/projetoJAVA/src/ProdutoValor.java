public class ProdutoValor {
    String nome;
    double valor;

    ProdutoValor(String nome, double valor) {
        this.nome = nome;
        this.valor = valor;
    }

    boolean altoValor() {
        return valor >= 1000.00;
    }
}


