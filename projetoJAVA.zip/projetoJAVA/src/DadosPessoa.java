public class DadosPessoa {
    String nome;
    int idade;
    String nacionalidade;

    DadosPessoa(String nome, int idade, String nacionalidade) {
        this.nome = nome;
        this.idade = idade;
        this.nacionalidade = nacionalidade;
    }

    boolean podeDirigir() {
        return idade >= 18;
    }

    boolean aptoConcurso() {
        return idade >= 18 && nacionalidade.equalsIgnoreCase("brasileira");
    }
}


